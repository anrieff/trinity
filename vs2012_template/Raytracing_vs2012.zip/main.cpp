#include "SDL.h"

/*
	Please, copy 'SDL.dll' in your '<Project_name>\<Project_name>' folde
	(the folder in which 'main.cpp' is located)
*/

int main(int argc, char** argv)
{

    SDL_Init(SDL_INIT_EVERYTHING);
    SDL_Quit();
 
    return 0;
}